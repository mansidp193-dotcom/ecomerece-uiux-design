---
name: Lumina SaaS System
colors:
  surface: '#f9f9ff'
  surface-dim: '#d4daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e8eeff'
  surface-container-high: '#e3e8f9'
  surface-container-highest: '#dde2f3'
  on-surface: '#161c27'
  on-surface-variant: '#484552'
  inverse-surface: '#2a303d'
  inverse-on-surface: '#ecf0ff'
  outline: '#797583'
  outline-variant: '#c9c4d4'
  surface-tint: '#604fb1'
  primary: '#5d4dae'
  on-primary: '#ffffff'
  primary-container: '#7666c9'
  on-primary-container: '#fffbff'
  inverse-primary: '#c9beff'
  secondary: '#a14001'
  on-secondary: '#ffffff'
  secondary-container: '#fd8547'
  on-secondary-container: '#682700'
  tertiary: '#0c6764'
  on-tertiary: '#ffffff'
  tertiary-container: '#32807d'
  on-tertiary-container: '#f3fffd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e6deff'
  primary-fixed-dim: '#c9beff'
  on-primary-fixed: '#1b0063'
  on-primary-fixed-variant: '#473697'
  secondary-fixed: '#ffdbcc'
  secondary-fixed-dim: '#ffb694'
  on-secondary-fixed: '#351000'
  on-secondary-fixed-variant: '#7b2f00'
  tertiary-fixed: '#a4f0ec'
  tertiary-fixed-dim: '#88d4cf'
  on-tertiary-fixed: '#00201f'
  on-tertiary-fixed-variant: '#00504d'
  background: '#f9f9ff'
  on-background: '#161c27'
  surface-variant: '#dde2f3'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4.25rem
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: 0em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system delivers an approachable, focused, and luminous modern software aesthetic. It combines the clarity of contemporary corporate SaaS with the calm reassurance of soft, tinted ambient surfaces. 

### Design Philosophy & Aesthetic Movement
The aesthetic synthesizes Modern Corporate clarity with soft atmospheric tinting. Interfaces transition away from harsh sterile grays into an inviting canvas grounded in soft lavender and cool off-white tones. The design prioritizes visual ergonomics: interfaces reduce cognitive fatigue during prolonged operational sessions by maintaining balanced contrast, rhythmic white space, and gentle boundary cues.

### Emotional Response & Personality
- **Reassuring & Poised:** Soft background hues remove cold institutional friction, providing a calm environment for complex data workflows.
- **Precise & Capable:** Clean geometry, balanced typographic weights, and deliberate micro-accents signal enterprise reliability.
- **Warm & Energetic:** Strategic warm accenting balances the lavender-slate baseline to guide task completion without alarmist visual noise.

## Colors

The color palette relies on atmospheric layered neutrals paired with high-clarity primary hues and nuanced semantic alerts.

### Palette Architecture
- **Canvas & Surfaces:**
  - Background Canvas: `#E9E8FA` (Soft Lavender) provides a tinted resting background that isolates active work windows.
  - Surface White: `#FDFDFD` provides pure contrast for foreground cards, forms, and primary workspaces.
  - Structural Sidebar / Off-White: `#FAFBFD` frames secondary navigation and tool palettes.
  - Active Lavender: `#EFEEFE` designates hover states, selection fills, and active navigation list items.
  - Border Subtle: `#DCE6ED` constructs crisp, low-glare partitions and structural dividers.

- **Typography & Content:**
  - Primary Text: `#1B212D` (Deep Dark Navy) ensures WCAG AAA readability on light surfaces without the stark harshness of pure `#000000`.
  - Secondary Text: `#59646F` supplies calm hierarchy for metadata, captions, and secondary labels.

- **Core Brand Accents:**
  - Primary Core: `#7969CC` (Purple Accent) commands primary calls to action, brand touchpoints, and active state highlights.
  - Secondary Core: `#F57F42` (Primary Orange Accent) directs critical conversion paths, badges, and proactive user steps.
  - Tertiary Accent: `#71BCB8` (Teal Accent) anchors analytical metrics, charts, and balance indicators.
  - Auxiliary Accent: `#D6A65C` (Gold Accent) highlights premium tiers, warnings, and attention items.

- **Status & Feedback System:**
  - Success: `#6FD2BE` (Soft Green) for successful states and positive trends.
  - Informative Lavender: `#D7D5FF` for contextual highlights and system messages.
  - Alert / Caution: `#FEEAD2` (Soft Orange) for warning surfaces paired with `#F57F42` text.
  - Accent / Notice: `#C6F4F2` (Soft Teal) for background tag fills and neutral progress indicators.

## Typography

The typographic system utilizes a paired dual-engine hierarchy: **Plus Jakarta Sans** provides rounded, friendly confidence in headlines and structural page anchors, while **Inter** delivers neutral, highly legible utility for dense interface controls, dashboards, tables, and copy.

### Hierarchy & Usage
- **Display & Large Headlines:** Reserved for marketing headers, primary onboarding greetings, and core operational KPI counters. Tracking is tightened to maintain visual cohesion.
- **Section Headlines (`headline-md`, `headline-sm`):** Anchor card groupings, dashboard widgets, and modal titles.
- **Body Elements:** Standardized on `Inter` with open apertures and neutral proportions to preserve legibility across various screen resolutions.
- **Labels & Overlines:** Rendered in medium to semibold weights with slight letter-spacing expansion to ensure instant scannability on badges, buttons, form captions, and table column headers.

## Layout & Spacing

The layout is built on an adaptive 12-column responsive fluid grid anchored by an 8pt base layout scale.

### Grid & Layout Engine
- **Desktop (1200px+):** 12-column grid, `2.5rem` (`40px`) outer canvas margin, `1.5rem` (`24px`) gutters. App layouts feature a persistent fixed or collapsible sidebar (`#FAFBFD`) at `260px` width, with fluid main content panels nested over the `#E9E8FA` canvas.
- **Tablet (768px – 1199px):** 8-column grid, `1.5rem` (`24px`) margins, `1rem` (`16px`) gutters. Sidebars fold into off-canvas drawer overlays.
- **Mobile (320px – 767px):** 4-column grid, `1rem` (`16px`) margins, `1rem` (`16px`) gutters. Multi-column cards stack vertically into single-column containers.

### Spacing Application
- Use `space-xs` (4px) and `space-sm` (8px) for internal control padding (e.g., button internals, tag spacing, icon-to-label gaps).
- Use `space-md` (16px) for intra-card content separation, form field gaps, and compact list padding.
- Use `space-lg` (24px) for card body padding, module dividers, and nested section gaps.
- Use `space-xl` (32px) and `space-2xl` (48px) for canvas module offsets, section margins, and milestone transitions.

## Elevation & Depth

Visual depth is achieved through a hybrid of crisp structural separation and soft ambient shadows tinted with lavender-slate undertones. This prevents the mudded, dirty appearance associated with standard charcoal dropshadows on tinted canvases.

### Elevation Levels
- **Level 0 (Flat Canvas / Ground):** The background canvas (`#E9E8FA`) sits at the base level. No shadow.
- **Level 1 (Structural Inset / Slabs):** Sidebar panels and tool rails (`#FAFBFD`) rest flush, divided horizontally or vertically by a 1px border of `#DCE6ED`.
- **Level 2 (Cards, Panels & Data Containers):** Foreground panels (`#FDFDFD`) float with a subtle, diffused drop shadow:
  - `box-shadow: 0 2px 8px -2px rgba(27, 33, 45, 0.04), 0 6px 16px -4px rgba(121, 105, 204, 0.06);`
  - Border: 1px solid `#DCE6ED`.
- **Level 3 (Dropdowns, Popovers & Hover Cards):** Contextual elements lift cleanly above surrounding tiles:
  - `box-shadow: 0 8px 24px -6px rgba(27, 33, 45, 0.08), 0 16px 32px -8px rgba(121, 105, 204, 0.12);`
  - Border: 1px solid `#DCE6ED`.
- **Level 4 (Modals, Dialogs & Global Overlays):** Major modal interventions rest above a tinted backdrop overlay (`rgba(27, 33, 45, 0.4)`):
  - `box-shadow: 0 24px 48px -12px rgba(27, 33, 45, 0.16), 0 32px 64px -16px rgba(121, 105, 204, 0.14);`

## Shapes

The design system uses standard `roundedness: 2`, creating a 0.5rem (8px) foundational radius that balances modern warmth with enterprise precision.

### Radius Token Mapping
- **Base Components (`rounded` / `0.5rem` / `8px`):** Standard buttons, text inputs, form select triggers, dropdown menus, table cell selections, and alert containers.
- **Sub-elements (`rounded-sm` / `0.25rem` / `4px`):** Checkboxes, inline code tokens, tooltips, and micro-metric badges.
- **Large Containers (`rounded-lg` / `1rem` / `16px`):** Content cards, data widgets, dashboard viewports, and modals.
- **Structural Outers (`rounded-xl` / `1.5rem` / `24px`):** Floating hero banners, app layout wrappers, and marketing dialog containers.
- **Full Radius (`rounded-full` / `9999px`):** Metric status chips, circular icon buttons, avatars, and segmented toggle pills.

## Components

### Buttons
- **Primary:** Background `#7969CC`, text `#FDFDFD`, height `40px`, padding `0 1.25rem`, border-radius `0.5rem`, font `Inter` semibold `0.875rem`. Hover state transitions to `#6857BE`. Focus ring shows a `2px` ring offset in `#D7D5FF`.
- **Secondary (Accent Action):** Background `#F57F42`, text `#FDFDFD`. Used sparingly for primary page conversion or distinct positive task completion.
- **Outline / Secondary Neutral:** Background `#FDFDFD`, border `1px solid #DCE6ED`, text `#1B212D`. Hover initiates background `#EFEEFE` and border-color `#7969CC`.
- **Ghost:** Transparent background, text `#59646F`. Hover applies `#EFEEFE` background and `#1B212D` text color.

### Inputs & Form Controls
- **Text Inputs:** Height `40px`, background `#FDFDFD`, border `1px solid #DCE6ED`, border-radius `0.5rem`, typography `Inter` `0.875rem` (`#1B212D`). Placeholder text uses `#59646F` at 60% opacity.
- **Active / Focus:** Border transitions to `#7969CC` with an ambient glow of `0 0 0 3px rgba(121, 105, 204, 0.15)`.
- **Error State:** Border shifts to `#F57F42` with an ambient glow of `0 0 0 3px rgba(245, 127, 66, 0.15)`.

### Chips & Badges
- **Informative Status:** Background `#D7D5FF`, text `#7969CC`, border-radius `9999px`, padding `0.25rem 0.75rem`, font `label-md`.
- **Success Status:** Background `#C6F4F2`, text `#1B212D` (with `#6FD2BE` dot indicator).
- **Warning / Alert:** Background `#FEEAD2`, text `#F57F42`.

### Checkboxes & Radios
- **Unchecked:** Size `18px`, border `1.5px solid #DCE6ED`, background `#FDFDFD`, border-radius `0.25rem` (radios use `50%`).
- **Checked:** Background `#7969CC`, border-color `#7969CC`, with white check or radio dot icon.

### Cards & Panels
- Constructed with `#FDFDFD` surface fill, `1px solid #DCE6ED` border, and `rounded-lg` (`1rem`) corner radius.
- Standard interior padding defaults to `1.5rem` (`space-lg`).
- Header bars within cards can use a subtle divider border of `1px solid #DCE6ED` with secondary metadata set in `body-sm` (`#59646F`).

### Lists & Tables
- **Table Headers:** Background `#FAFBFD`, border-bottom `1px solid #DCE6ED`, text `#59646F`, typography `label-md` uppercase.
- **Table Rows:** Background `#FDFDFD`, border-bottom `1px solid #DCE6ED`. Hover row changes background to `#EFEEFE` with smooth 150ms transition.
- **Active / Selected Row:** Background `#EFEEFE` with a `3px` left border accent in `#7969CC`.