---
name: Artisanal Heritage Kitchen
colors:
  surface: '#fff8f6'
  surface-dim: '#e1d8d6'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2f0'
  surface-container: '#f5ecea'
  surface-container-high: '#efe6e4'
  surface-container-highest: '#e9e1df'
  on-surface: '#1e1b1a'
  on-surface-variant: '#404940'
  inverse-surface: '#342f2e'
  inverse-on-surface: '#f8efed'
  outline: '#707a6f'
  outline-variant: '#bfc9bd'
  surface-tint: '#1f6c3a'
  primary: '#004c22'
  on-primary: '#ffffff'
  primary-container: '#166534'
  on-primary-container: '#93e0a2'
  inverse-primary: '#8bd79b'
  secondary: '#a73a00'
  on-secondary: '#ffffff'
  secondary-container: '#fd651e'
  on-secondary-container: '#571a00'
  tertiary: '#593b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#785000'
  on-tertiary-container: '#ffc56b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a6f4b5'
  primary-fixed-dim: '#8bd79b'
  on-primary-fixed: '#00210b'
  on-primary-fixed-variant: '#005226'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb599'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#ffddb0'
  tertiary-fixed-dim: '#ffba46'
  on-tertiary-fixed: '#281800'
  on-tertiary-fixed-variant: '#614000'
  background: '#fff8f6'
  on-background: '#1e1b1a'
  surface-variant: '#e9e1df'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies the warmth, pride, and generational authenticity of Indian home kitchens. It elevates traditional food crafts—such as slow-sun-dried *lonche*, hand-rolled *papad*, stone-ground *masalas*, and festive *ladoos*—into a polished, modern culinary marketplace. 

The aesthetic seamlessly bridges artisanal heritage with contemporary, accessible mobile product design. Grounded in a tactile, clean editorial style, it pairs warm spice tones with deep botanic neem green to signal natural freshness, purity, and organic integrity. The experience is designed to feel empowering and dignified for culinary artisans, providing high-contrast readability, generous touch surfaces, and reassuring visual feedback throughout onboarding and daily seller operations.

## Colors

The palette draws inspiration directly from Indian pantries and botanical freshness:

- **Primary (`#166534`)**: Deep Neem / Coriander Green. Represents herbal purity, farm-fresh ingredients, verification, and grounded trust. Used for primary CTAs, active indicators, verification badges, and key milestones.
- **Secondary (`#EA580C`)**: Saffron & Kesar Spice Orange. Conveys warmth, appetite, culinary passion, and vibrant hospitality. Applied to promotional highlights, alert actions, secondary calls to action, and energetic badges.
- **Tertiary (`#CA8A04`)**: Warm Haldi & Ghee Gold. Imparts heritage value, artisan craftsmanship tiers, and quality certification accents.
- **Neutral Surface & Backgrounds**:
  - Main Background: `#FDFBF7` (Soft warm buttermilk cream).
  - Elevated Surfaces & Cards: `#FFFFFF` (Pure white for crisp contrast against cream).
  - Subtle Surface Containers: `#FFF9F2` (Sunlit warm tint for inputs, active panels, and step counters).
- **Text & Borders**:
  - Primary Typography: `#292524` (Deep roasted charcoal-brown for softer contrast than pure black).
  - Muted Labels & Secondary Text: `#78716C` (Warm stone grey).
  - Hairlines & Card Borders: `#F5EBE1` (Soft spiced grain outline).

## Typography

The typographic pairing reflects dual values: artisanal storytelling and effortless operational clarity.

- **Headlines (`Noto Serif`)**: Brings timeless editorial authority and traditional culinary craftsmanship into prominent focus. Used exclusively for screen titles, milestone celebrations, modal headlines, and merchant showcase banners.
- **Body & Labels (`Plus Jakarta Sans`)**: Delivers geometric clarity, welcoming friendliness, and high legibility across small mobile viewports (specifically optimized for 390px widths). Applied to operational figures, forms, onboarding microcopy, badge labels, and dashboard metrics.

## Layout & Spacing

Designed with an intentional mobile-first focus optimized for 390×844 displays:

- **Outer Margins**: Set to `1.25rem` (20px) on mobile viewports to balance card breathing room with readable text density.
- **Vertical Flow**: 8px baseline rhythm across all views. Section headers, card stacks, and floating bottom sheets maintain a standardized spacing hierarchy (`space-sm` for related micro-elements, `space-md` for internal card padding, `space-lg` between distinct module blocks).
- **Sticky Actions**: Standard 56px bottom touch zone reserved for primary onboarding steps and order fulfillment actions, padded with safe margins above the screen floor.

## Elevation & Depth

Visual hierarchy uses warm, sun-cured ambient depth rather than harsh synthetic grey drops.

- **Level 0 (Flat Base)**: Natural `#FDFBF7` canvas background.
- **Level 1 (Card & Module Surface)**: Pure `#FFFFFF` resting over `#FDFBF7`, framed by a soft border (`1px solid #F5EBE1`) and an ambient tinted shadow: `0 4px 16px -2px rgba(67, 40, 16, 0.05)`.
- **Level 2 (Interactive Floating Elements & Quick Bars)**: Higher elevation for sticky bottom bars, notification toasts, and verified badge cards: `0 8px 24px -4px rgba(67, 40, 16, 0.08)`.
- **Level 3 (Modals & Recipe/Batch Drawers)**: Deep focus shadow: `0 16px 36px -6px rgba(41, 37, 36, 0.16)`.

## Shapes

The shape vocabulary uses gentle, welcoming curves reflecting hand-kneaded dough, clay pots, and spice jars:

- **Base Radius (`0.5rem` / 8px)**: Used for status tags, verified pill labels, and compact micro-chips.
- **Container Radius (`rounded-lg` / `1rem` / 16px)**: Applied across input fields, text areas, and primary button containers for tactile touch targets.
- **Card Radius (`rounded-xl` / `1.5rem` / 24px)**: Applied to product cards, metrics overviews, order summaries, and modular onboarding wrappers to produce an inviting, organic feel.

## Components

### Buttons
- **Primary Action Button**: Deep Neem Green (`#166534`) fill, `#FFFFFF` text, `rounded-xl`, min-height 52px, `font-semibold` (`label-lg`). Includes subtle warm inner highlight and active scale compression (0.98).
- **Secondary / Spice Action Button**: Saffron Orange (`#EA580C`) fill or outline (`2px solid #EA580C`), used for time-sensitive kitchen updates, live inventory alerts, and instant payouts.
- **Tertiary / Ghost Button**: `#292524` text with light warm cream hover/press state (`#FFF9F2`), `rounded-lg`.

### Input Fields
- Enclosed with `rounded-xl`, baseline height 50px, border `1.5px solid #F5EBE1`, surface `#FFFFFF`.
- On focus, stroke transitions to `#166534` accompanied by a soft glow ring: `0 0 0 3px rgba(22, 101, 52, 0.12)`.
- Placeholder text styled in warm stone grey (`#A8A29E`). Pre-filled and currency symbols (e.g., `₹`) set in medium-weight primary neutral (`#292524`).

### Onboarding Step Progress
- Step indicator combines segmented bar lines and numbered nodes. Active node is highlighted in `#166534` with an outer halo in `#22C55E`; completed stages switch to `#166534` with white checkmarks; pending steps use warm sand (`#E7DED4`).

### Cards & Modules
- Clean white surfaces bordered by `#F5EBE1` with `rounded-xl` (24px) perimeter. 
- Kitchen metric cards feature bold numbers in `Noto Serif` paired with supportive status chips and small icon accents (e.g., spice jars, batch weight indicators).

### Badges & Verification Tokens
- **FSSAI & Artisan Verified**: Deep green pill badge (`#DCFCE7` background, `#166534` text and icon), accompanied by an artisanal seal glyph.
- **Batch Quality Badges**: Saffron and warm gold pills (`#FEF3C7` background, `#92400E` text) denoting specialty crafts such as "Sun-Dried", "Hand-Pounded", or "No Added Preservatives".

### Checkboxes & Radios
- Size 22×22px, `rounded-md` for checkboxes and circular for radios. Inactive state has `1.5px solid #D6D3D1`. Active state fills with `#166534` featuring a crisp white center icon.